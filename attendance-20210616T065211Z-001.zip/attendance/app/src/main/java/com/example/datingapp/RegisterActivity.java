package com.example.datingapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class RegisterActivity extends AppCompatActivity {
    EditText TextUsername;
    EditText TextPassword;
    EditText TextPassword2;
    Button ButtonRegister;
    TextView TextViewLogin;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        TextUsername =(EditText)findViewById(R.id.edittext_user);
        TextPassword =(EditText)findViewById(R.id.edittext_pass);
        TextPassword2 =(EditText)findViewById(R.id.edittext_pass2);
        ButtonRegister =(Button) findViewById(R.id.button_register);
        TextViewLogin=(TextView)findViewById(R.id.textview_Login1);
        TextViewLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent LoginIntent=new Intent(RegisterActivity.this,MainActivity.class);
                startActivity(LoginIntent);
            }
        });


    }
}
