package com.example.datingapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText TextUsername;
    EditText TextPassword;
    Button ButtonLogin;
    TextView TextViewRegister;
    FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toast.makeText(MainActivity.this,"sucess",Toast.LENGTH_LONG).show();
        TextUsername =(EditText)findViewById(R.id.edittext_username);
        TextPassword =(EditText)findViewById(R.id.edittext_password);
        ButtonLogin =(Button) findViewById(R.id.button_login);
        TextViewRegister =(TextView)findViewById(R.id.textview_register);
        TextViewRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent registerintent=new Intent(MainActivity.this,RegisterActivity.class);
                startActivity(registerintent);
            }
        });
    }
}
